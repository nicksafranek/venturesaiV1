import { useState } from 'react';
import {
  Zap,
  Target,
  BarChart3,
  MessageSquare,
  CheckCircle2,
  ArrowRight,
  Sparkles
} from 'lucide-react';

function App() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Thank you! We\'ll be in touch soon.');
    setFormData({ name: '', email: '', company: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-[#0a0a1f] text-white">
      <nav className="fixed top-0 w-full bg-black backdrop-blur-md z-50 border-b border-purple-900/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center relative overflow-hidden">
              <svg className="w-4 h-4 sm:w-5 sm:h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="2" fill="white" className="opacity-90"/>
                <circle cx="6" cy="8" r="1.5" fill="white" className="opacity-70"/>
                <circle cx="18" cy="8" r="1.5" fill="white" className="opacity-70"/>
                <circle cx="6" cy="16" r="1.5" fill="white" className="opacity-70"/>
                <circle cx="18" cy="16" r="1.5" fill="white" className="opacity-70"/>
                <line x1="6" y1="8" x2="10.5" y2="11" stroke="white" strokeWidth="0.8" className="opacity-60"/>
                <line x1="18" y1="8" x2="13.5" y2="11" stroke="white" strokeWidth="0.8" className="opacity-60"/>
                <line x1="6" y1="16" x2="10.5" y2="13" stroke="white" strokeWidth="0.8" className="opacity-60"/>
                <line x1="18" y1="16" x2="13.5" y2="13" stroke="white" strokeWidth="0.8" className="opacity-60"/>
                <circle cx="12" cy="4" r="1" fill="white" className="opacity-50"/>
                <circle cx="12" cy="20" r="1" fill="white" className="opacity-50"/>
                <line x1="12" y1="4" x2="12" y2="10" stroke="white" strokeWidth="0.6" className="opacity-40"/>
                <line x1="12" y1="20" x2="12" y2="14" stroke="white" strokeWidth="0.6" className="opacity-40"/>
              </svg>
              <div className="absolute inset-0 bg-gradient-to-tr from-purple-400/20 via-transparent to-indigo-400/20 animate-pulse"></div>
            </div>
            <span className="text-lg sm:text-xl md:text-2xl font-bold text-white">
              Ventures.ai
            </span>
          </div>
          <div className="flex items-center gap-3 sm:gap-6 md:gap-8">
            <a href="#services" className="hidden sm:inline text-gray-300 hover:text-white transition-colors text-sm">Services</a>
            <a href="#about" className="hidden sm:inline text-gray-300 hover:text-white transition-colors text-sm">About</a>
            <button
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-4 py-2 sm:px-6 sm:py-2.5 bg-gradient-to-r from-purple-700 to-indigo-800 hover:from-purple-600 hover:to-indigo-700 rounded-lg transition-all duration-300 font-medium text-white text-xs sm:text-sm whitespace-nowrap"
            >
              Start A Project
            </button>
          </div>
        </div>
      </nav>

      <section className="pt-24 sm:pt-32 pb-16 sm:pb-24 px-4 sm:px-6 relative overflow-hidden min-h-[85vh] sm:min-h-[90vh] flex items-center">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a0f3e] via-[#0a0a1f] to-[#0d1b4d]"></div>
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-[500px] sm:w-[800px] h-[500px] sm:h-[800px] bg-gradient-to-br from-purple-700/15 via-indigo-600/15 to-purple-500/15 rounded-full filter blur-[100px] sm:blur-[150px] opacity-60"></div>
          <div className="absolute bottom-0 left-0 w-[400px] sm:w-[600px] h-[400px] sm:h-[600px] bg-gradient-to-tr from-purple-900/15 via-indigo-700/15 to-purple-600/15 rounded-full filter blur-[80px] sm:blur-[120px] opacity-50"></div>
        </div>

        <div className="max-w-7xl mx-auto relative z-10 grid md:grid-cols-2 gap-8 sm:gap-12 items-center">
          <div>
            <div className="inline-block mb-4 sm:mb-6 px-3 sm:px-4 py-1.5 sm:py-2 bg-purple-500/10 border border-purple-400/20 rounded-full text-xs font-medium text-purple-300 uppercase tracking-wider">
              Automate. Optimize. Scale.
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-bold mb-4 sm:mb-6 leading-[0.95]">
              <span className="bg-gradient-to-r from-purple-400 via-purple-500 to-indigo-500 bg-clip-text text-transparent">
                VENTURES.AI
              </span>
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-gray-300 mb-8 sm:mb-10 leading-relaxed max-w-lg">
              AI Automation Team Working With Companies To Scale More Efficiently
            </p>
            <button
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="group px-6 sm:px-8 py-3.5 sm:py-4 bg-gradient-to-r from-purple-700 to-indigo-800 hover:from-purple-600 hover:to-indigo-700 rounded-lg transition-all duration-300 font-semibold text-white inline-flex items-center gap-2 shadow-lg text-base"
            >
              Get A Quote
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="hidden md:block relative">
            <div className="relative w-full h-[500px]">
              <svg className="w-full h-full" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M150 100 L350 100 L380 130 L380 380 L150 380 L120 350 L120 130 Z"
                      stroke="url(#gradient1)" strokeWidth="2" fill="none" opacity="0.6"/>
                <path d="M180 200 L180 350 L320 350 L320 200 Z"
                      stroke="url(#gradient2)" strokeWidth="2" fill="rgba(96, 165, 250, 0.05)"/>
                <circle cx="250" cy="275" r="40" stroke="url(#gradient3)" strokeWidth="2" fill="rgba(139, 92, 246, 0.1)"/>
                <path d="M230 275 L245 290 L270 260" stroke="#a78bfa" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>

                <defs>
                  <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#a78bfa" />
                    <stop offset="50%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor="#6366f1" />
                  </linearGradient>
                  <linearGradient id="gradient2" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#818cf8" />
                    <stop offset="100%" stopColor="#6366f1" />
                  </linearGradient>
                  <linearGradient id="gradient3" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor="#6366f1" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-20 md:py-24 px-4 sm:px-6 relative bg-gradient-to-b from-[#0a0a1f] to-[#0d1535]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 sm:mb-16 md:mb-20">
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6">
              <span className="text-white">How It </span>
              <span className="bg-gradient-to-r from-purple-400 to-indigo-500 bg-clip-text text-transparent">Works</span>
            </h2>
            <p className="text-gray-400 text-base sm:text-lg">Simple, Effective, Transformative</p>
          </div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-8">
            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-indigo-700/10 rounded-2xl sm:rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
              <div className="relative p-6 sm:p-8 md:p-10 bg-gradient-to-br from-[#1a1a3e]/80 to-[#0f1942]/80 border border-purple-500/10 rounded-2xl sm:rounded-3xl backdrop-blur-sm hover:border-cyan-400/30 transition-all duration-300">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-purple-500/20 to-indigo-500/20 rounded-xl sm:rounded-2xl flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform border border-purple-400/20">
                  <Target className="w-7 h-7 sm:w-8 sm:h-8 text-purple-400" />
                </div>
                <div className="text-4xl sm:text-5xl md:text-6xl font-bold bg-gradient-to-br from-purple-400 to-indigo-500 bg-clip-text text-transparent mb-3 sm:mb-4">01</div>
                <h3 className="text-xl sm:text-2xl font-bold mb-3 sm:mb-4 text-white">Identify Bottlenecks</h3>
                <p className="text-sm sm:text-base text-gray-400 leading-relaxed">
                  We analyze your business processes to uncover inefficiencies and automation opportunities
                </p>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/10 to-purple-700/10 rounded-2xl sm:rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
              <div className="relative p-6 sm:p-8 md:p-10 bg-gradient-to-br from-[#1a1a3e]/80 to-[#0f1942]/80 border border-purple-500/10 rounded-2xl sm:rounded-3xl backdrop-blur-sm hover:border-cyan-400/30 transition-all duration-300">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 rounded-xl sm:rounded-2xl flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform border border-indigo-400/20">
                  <Sparkles className="w-7 h-7 sm:w-8 sm:h-8 text-purple-400" />
                </div>
                <div className="text-4xl sm:text-5xl md:text-6xl font-bold bg-gradient-to-br from-purple-400 to-indigo-500 bg-clip-text text-transparent mb-3 sm:mb-4">02</div>
                <h3 className="text-xl sm:text-2xl font-bold mb-3 sm:mb-4 text-white">Design Automations</h3>
                <p className="text-sm sm:text-base text-gray-400 leading-relaxed">
                  We build tailored AI workflows that fit seamlessly into your existing operations
                </p>
              </div>
            </div>

            <div className="group relative sm:col-span-2 md:col-span-1">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-700/10 to-purple-600/10 rounded-2xl sm:rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
              <div className="relative p-6 sm:p-8 md:p-10 bg-gradient-to-br from-[#1a1a3e]/80 to-[#0f1942]/80 border border-purple-500/10 rounded-2xl sm:rounded-3xl backdrop-blur-sm hover:border-cyan-400/30 transition-all duration-300">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-indigo-500/20 to-purple-600/20 rounded-xl sm:rounded-2xl flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform border border-indigo-400/20">
                  <Zap className="w-7 h-7 sm:w-8 sm:h-8 text-purple-400" />
                </div>
                <div className="text-4xl sm:text-5xl md:text-6xl font-bold bg-gradient-to-br from-purple-400 to-indigo-500 bg-clip-text text-transparent mb-3 sm:mb-4">03</div>
                <h3 className="text-xl sm:text-2xl font-bold mb-3 sm:mb-4 text-white">Deploy & Optimize</h3>
                <p className="text-sm sm:text-base text-gray-400 leading-relaxed">
                  We integrate and monitor your systems for peak performance and continuous improvement
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="services" className="py-16 sm:py-20 md:py-24 px-4 sm:px-6 relative bg-[#0a0a1f]">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0d1535] via-[#0a0a1f] to-[#1a0f3e] opacity-50"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-12 sm:mb-16 md:mb-20">
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6">
              <span className="text-white">Our </span>
              <span className="bg-gradient-to-r from-purple-400 to-indigo-500 bg-clip-text text-transparent">Services</span>
            </h2>
            <p className="text-gray-400 text-base sm:text-lg">Comprehensive AI Automation Solutions</p>
          </div>

          <div className="grid sm:grid-cols-2 gap-6 sm:gap-8">
            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-blue-600/5 rounded-2xl sm:rounded-3xl"></div>
              <div className="relative p-6 sm:p-8 md:p-10 bg-gradient-to-br from-[#1a1a3e]/60 to-[#0f1942]/60 border border-purple-500/10 rounded-2xl sm:rounded-3xl backdrop-blur-sm hover:border-cyan-400/20 transition-all duration-300">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-purple-500/20 to-indigo-500/20 rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 border border-purple-400/20">
                  <MessageSquare className="w-6 h-6 sm:w-7 sm:h-7 text-purple-400" />
                </div>
                <h3 className="text-lg sm:text-xl md:text-2xl font-bold mb-3 sm:mb-4 text-white">Automated Personalized Outreach</h3>
                <p className="text-sm sm:text-base text-gray-400 leading-relaxed mb-4 sm:mb-6">
                  Contact large sums of leads automatically with personalized emails that convert
                </p>
                <button className="text-purple-400 hover:text-purple-300 font-semibold text-sm inline-flex items-center gap-2 group-hover:gap-3 transition-all min-h-[44px] min-w-[44px]">
                  Learn More <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 to-cyan-600/5 rounded-2xl sm:rounded-3xl"></div>
              <div className="relative p-6 sm:p-8 md:p-10 bg-gradient-to-br from-[#1a1a3e]/60 to-[#0f1942]/60 border border-purple-500/10 rounded-2xl sm:rounded-3xl backdrop-blur-sm hover:border-cyan-400/20 transition-all duration-300">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 border border-indigo-400/20">
                  <Target className="w-6 h-6 sm:w-7 sm:h-7 text-purple-400" />
                </div>
                <h3 className="text-lg sm:text-xl md:text-2xl font-bold mb-3 sm:mb-4 text-white">Automated Lead Generation</h3>
                <p className="text-sm sm:text-base text-gray-400 leading-relaxed mb-4 sm:mb-6">
                  Use AI to find, qualify, and nurture leads automatically around the clock
                </p>
                <button className="text-purple-400 hover:text-purple-300 font-semibold text-sm inline-flex items-center gap-2 group-hover:gap-3 transition-all min-h-[44px] min-w-[44px]">
                  Learn More <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-600/5 to-purple-600/5 rounded-2xl sm:rounded-3xl"></div>
              <div className="relative p-6 sm:p-8 md:p-10 bg-gradient-to-br from-[#1a1a3e]/60 to-[#0f1942]/60 border border-purple-500/10 rounded-2xl sm:rounded-3xl backdrop-blur-sm hover:border-cyan-400/20 transition-all duration-300">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-indigo-500/20 to-purple-600/20 rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 border border-indigo-400/20">
                  <Zap className="w-6 h-6 sm:w-7 sm:h-7 text-purple-400" />
                </div>
                <h3 className="text-lg sm:text-xl md:text-2xl font-bold mb-3 sm:mb-4 text-white">Custom AI Integrations</h3>
                <p className="text-sm sm:text-base text-gray-400 leading-relaxed mb-4 sm:mb-6">
                  Connect CRMs, data tools, and communication platforms seamlessly
                </p>
                <button className="text-purple-400 hover:text-purple-300 font-semibold text-sm inline-flex items-center gap-2 group-hover:gap-3 transition-all min-h-[44px] min-w-[44px]">
                  Learn More <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-cyan-600/5 rounded-2xl sm:rounded-3xl"></div>
              <div className="relative p-6 sm:p-8 md:p-10 bg-gradient-to-br from-[#1a1a3e]/60 to-[#0f1942]/60 border border-purple-500/10 rounded-2xl sm:rounded-3xl backdrop-blur-sm hover:border-cyan-400/20 transition-all duration-300">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-purple-500/20 to-indigo-500/20 rounded-lg sm:rounded-xl flex items-center justify-center mb-4 sm:mb-6 border border-purple-400/20">
                  <BarChart3 className="w-6 h-6 sm:w-7 sm:h-7 text-purple-400" />
                </div>
                <h3 className="text-lg sm:text-xl md:text-2xl font-bold mb-3 sm:mb-4 text-white">24/7 Customer Support Agents</h3>
                <p className="text-sm sm:text-base text-gray-400 leading-relaxed mb-4 sm:mb-6">
                  Chatbots with knowledge base of company info, answering FAQs and setting appointments
                </p>
                <button className="text-purple-400 hover:text-purple-300 font-semibold text-sm inline-flex items-center gap-2 group-hover:gap-3 transition-all min-h-[44px] min-w-[44px]">
                  Learn More <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-20 md:py-24 px-4 sm:px-6 relative bg-gradient-to-b from-[#1a0f3e] via-[#0a0a1f] to-[#0d1535]">
        <div className="absolute inset-0">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] sm:w-[600px] h-[400px] sm:h-[600px] bg-gradient-to-br from-purple-600/10 via-indigo-700/10 to-purple-500/10 rounded-full filter blur-[80px] sm:blur-[100px]"></div>
        </div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-12 sm:mb-16 md:mb-20">
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6">
              <span className="text-white">Results That </span>
              <span className="bg-gradient-to-r from-purple-400 to-indigo-500 bg-clip-text text-transparent">Matter</span>
            </h2>
            <p className="text-gray-400 text-base sm:text-lg">Real Impact For Real Businesses</p>
          </div>

          <div className="grid sm:grid-cols-2 gap-6 sm:gap-8 md:gap-10 max-w-5xl mx-auto">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-indigo-700/20 rounded-2xl sm:rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
              <div className="relative p-8 sm:p-10 md:p-12 bg-gradient-to-br from-[#1a1a3e]/80 to-[#0f1942]/80 border border-purple-500/20 rounded-2xl sm:rounded-3xl text-center backdrop-blur-sm">
                <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-purple-400/20 to-indigo-500/20 rounded-full flex items-center justify-center mx-auto mb-6 sm:mb-8 border-2 border-purple-400/30">
                  <CheckCircle2 className="w-8 h-8 sm:w-10 sm:h-10 text-purple-400" />
                </div>
                <div className="text-5xl sm:text-6xl md:text-7xl font-bold mb-3 sm:mb-4 bg-gradient-to-r from-purple-400 via-indigo-500 to-purple-600 bg-clip-text text-transparent">
                  30+
                </div>
                <div className="text-xl sm:text-2xl font-semibold text-white mb-2">Hours Saved</div>
                <p className="text-sm sm:text-base text-gray-400">
                  Per Week Per Team Through Intelligent Automation
                </p>
              </div>
            </div>

            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 to-purple-700/20 rounded-2xl sm:rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
              <div className="relative p-8 sm:p-10 md:p-12 bg-gradient-to-br from-[#1a1a3e]/80 to-[#0f1942]/80 border border-purple-500/20 rounded-2xl sm:rounded-3xl text-center backdrop-blur-sm">
                <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-purple-400/20 to-indigo-500/20 rounded-full flex items-center justify-center mx-auto mb-6 sm:mb-8 border-2 border-purple-400/30">
                  <CheckCircle2 className="w-8 h-8 sm:w-10 sm:h-10 text-purple-400" />
                </div>
                <div className="text-5xl sm:text-6xl md:text-7xl font-bold mb-3 sm:mb-4 bg-gradient-to-r from-purple-400 via-indigo-500 to-purple-600 bg-clip-text text-transparent">
                  50%
                </div>
                <div className="text-xl sm:text-2xl font-semibold text-white mb-2">Increase</div>
                <p className="text-sm sm:text-base text-gray-400">
                  In Lead Response Rate With AI-Powered Outreach
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="about" className="py-16 sm:py-20 md:py-24 px-4 sm:px-6 relative bg-[#0a0a1f]">
        <div className="max-w-5xl mx-auto relative z-10">
          <div className="text-center mb-8 sm:mb-10 md:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6">
              <span className="text-white">About </span>
              <span className="bg-gradient-to-r from-purple-400 to-indigo-500 bg-clip-text text-transparent">Ventures.ai</span>
            </h2>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-blue-600/5 rounded-2xl sm:rounded-3xl blur-xl"></div>
            <div className="relative p-6 sm:p-8 md:p-12 bg-gradient-to-br from-[#1a1a3e]/60 to-[#0f1942]/60 border border-purple-500/10 rounded-2xl sm:rounded-3xl backdrop-blur-sm">
              <p className="text-gray-300 text-base sm:text-lg md:text-xl leading-relaxed text-center">
                Ventures.ai is a team of automation experts and AI engineers helping businesses
                embrace the future of work. We combine cutting-edge AI tools with real-world business
                strategy to deliver measurable results. Our mission is to empower companies to work
                smarter, not harder, by leveraging the transformative power of artificial intelligence.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="contact" className="py-16 sm:py-20 md:py-24 px-4 sm:px-6 relative bg-gradient-to-b from-[#0a0a1f] to-[#1a0f3e]">
        <div className="absolute inset-0">
          <div className="absolute bottom-0 right-0 w-[500px] sm:w-[700px] h-[500px] sm:h-[700px] bg-gradient-to-br from-purple-600/15 via-indigo-700/15 to-purple-500/15 rounded-full filter blur-[100px] sm:blur-[120px]"></div>
        </div>
        <div className="max-w-3xl mx-auto relative z-10">
          <div className="text-center mb-10 sm:mb-12 md:mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6">
              <span className="text-white">Ready to </span>
              <span className="bg-gradient-to-r from-purple-400 to-indigo-500 bg-clip-text text-transparent">Automate?</span>
            </h2>
            <p className="text-gray-400 text-base sm:text-lg md:text-xl px-4">
              Schedule A Free 15-Minute Strategy Call To Uncover Your Automation Opportunities.
            </p>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-blue-600/10 rounded-2xl sm:rounded-3xl blur-xl"></div>
            <form onSubmit={handleSubmit} className="relative p-6 sm:p-8 md:p-10 bg-gradient-to-br from-[#1a1a3e]/80 to-[#0f1942]/80 border border-purple-500/20 rounded-2xl sm:rounded-3xl backdrop-blur-sm">
              <div className="grid sm:grid-cols-2 gap-4 sm:gap-6 mb-4 sm:mb-6">
                <div>
                  <label className="block text-sm font-medium mb-2 sm:mb-3 text-gray-300">Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 sm:px-5 py-3 sm:py-3.5 bg-[#0a0a1f]/80 border border-purple-400/20 rounded-lg sm:rounded-xl focus:outline-none focus:border-purple-400/50 transition-colors text-white placeholder-gray-500 text-base"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2 sm:mb-3 text-gray-300">Email</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 sm:px-5 py-3 sm:py-3.5 bg-[#0a0a1f]/80 border border-purple-400/20 rounded-lg sm:rounded-xl focus:outline-none focus:border-purple-400/50 transition-colors text-white placeholder-gray-500 text-base"
                    placeholder="john@company.com"
                  />
                </div>
              </div>
              <div className="mb-4 sm:mb-6">
                <label className="block text-sm font-medium mb-2 sm:mb-3 text-gray-300">Company</label>
                <input
                  type="text"
                  required
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="w-full px-4 sm:px-5 py-3 sm:py-3.5 bg-[#0a0a1f]/80 border border-purple-400/20 rounded-lg sm:rounded-xl focus:outline-none focus:border-purple-400/50 transition-colors text-white placeholder-gray-500 text-base"
                  placeholder="Your Company Inc."
                />
              </div>
              <div className="mb-6 sm:mb-8">
                <label className="block text-sm font-medium mb-2 sm:mb-3 text-gray-300">Message</label>
                <textarea
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={4}
                  className="w-full px-4 sm:px-5 py-3 sm:py-3.5 bg-[#0a0a1f]/80 border border-purple-400/20 rounded-lg sm:rounded-xl focus:outline-none focus:border-cyan-400/50 transition-colors text-white resize-none placeholder-gray-500 text-base"
                  placeholder="Tell us about your automation needs..."
                />
              </div>
              <button
                type="submit"
                className="w-full px-6 sm:px-8 py-3.5 sm:py-4 bg-gradient-to-r from-purple-700 to-indigo-800 hover:from-purple-600 hover:to-indigo-700 rounded-lg sm:rounded-xl transition-all duration-300 font-semibold text-base sm:text-lg text-white shadow-lg min-h-[48px]"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      <footer className="py-8 sm:py-10 md:py-12 px-4 sm:px-6 bg-black border-t border-purple-900/10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 sm:gap-6">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center relative overflow-hidden">
                <svg className="w-4 h-4 sm:w-5 sm:h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="2" fill="white" className="opacity-90"/>
                  <circle cx="6" cy="8" r="1.5" fill="white" className="opacity-70"/>
                  <circle cx="18" cy="8" r="1.5" fill="white" className="opacity-70"/>
                  <circle cx="6" cy="16" r="1.5" fill="white" className="opacity-70"/>
                  <circle cx="18" cy="16" r="1.5" fill="white" className="opacity-70"/>
                  <line x1="6" y1="8" x2="10.5" y2="11" stroke="white" strokeWidth="0.8" className="opacity-60"/>
                  <line x1="18" y1="8" x2="13.5" y2="11" stroke="white" strokeWidth="0.8" className="opacity-60"/>
                  <line x1="6" y1="16" x2="10.5" y2="13" stroke="white" strokeWidth="0.8" className="opacity-60"/>
                  <line x1="18" y1="16" x2="13.5" y2="13" stroke="white" strokeWidth="0.8" className="opacity-60"/>
                  <circle cx="12" cy="4" r="1" fill="white" className="opacity-50"/>
                  <circle cx="12" cy="20" r="1" fill="white" className="opacity-50"/>
                  <line x1="12" y1="4" x2="12" y2="10" stroke="white" strokeWidth="0.6" className="opacity-40"/>
                  <line x1="12" y1="20" x2="12" y2="14" stroke="white" strokeWidth="0.6" className="opacity-40"/>
                </svg>
                <div className="absolute inset-0 bg-gradient-to-tr from-purple-400/20 via-transparent to-indigo-400/20 animate-pulse"></div>
              </div>
              <span className="text-lg sm:text-xl md:text-2xl font-bold text-white">
                Ventures.ai
              </span>
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-6 md:gap-8">
              <span className="text-gray-400 text-xs sm:text-sm">© 2025 Ventures.ai</span>
              <button className="text-gray-400 hover:text-purple-400 text-xs sm:text-sm transition-colors min-h-[44px] px-4">
                Privacy Policy
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
